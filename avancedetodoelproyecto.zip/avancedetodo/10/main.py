from interfaz import Interfaz

app = Interfaz()
app.run(None)
