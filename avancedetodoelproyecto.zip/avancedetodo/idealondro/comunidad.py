import random
import json
from ciudadano import Ciudadano

class Comunidad:
    def __init__(self, num_ciudadanos, promedio_conexion_fisica, enfermedad, num_infectados, probabilidad_conexion_fisica):
        self.num_ciudadanos = num_ciudadanos
        self.promedio_conexion_fisica = promedio_conexion_fisica
        self.enfermedad = enfermedad
        self.num_infectados = num_infectados
        self.probabilidad_conexion_fisica = probabilidad_conexion_fisica
        self.ciudadanos = self.generar_ciudadanos()
        self.infectar_ciudadanos_iniciales()

    def generar_ciudadanos(self):
        with open('nombres_apellidos.json', 'r', encoding='utf-8') as file:
            data = json.load(file)
            nombres = data['nombres']
            apellidos = data['apellidos']

        ciudadanos = []
        for i in range(self.num_ciudadanos):
            nombre = random.choice(nombres)
            apellido = random.choice(apellidos)
            familia = apellido  # Usar apellido como identificador de familia
            ciudadano = Ciudadano(id=i, nombre=nombre, apellido=apellido, familia=familia)
            ciudadanos.append(ciudadano)
        return ciudadanos

    def infectar_ciudadanos_iniciales(self):
        infectados_iniciales = random.sample(self.ciudadanos, self.num_infectados)
        for ciudadano in infectados_iniciales:
            ciudadano.infectar(self.enfermedad)

    def paso(self):
        nuevos_infectados = []
        for ciudadano in self.ciudadanos:
            if ciudadano.esta_infectado():
                for _ in range(self.promedio_conexion_fisica):
                    if random.random() < self.probabilidad_conexion_fisica:
                        contacto = random.choice(self.ciudadanos)
                        if contacto.esta_sano() and random.random() < self.enfermedad.infeccion_probable:
                            nuevos_infectados.append(contacto)

        for ciudadano in nuevos_infectados:
            ciudadano.infectar(self.enfermedad)

    def contar_estados(self):
        sanos = sum(1 for c in self.ciudadanos if c.esta_sano())
        infectados = sum(1 for c in self.ciudadanos if c.esta_infectado())
        recuperados = sum(1 for c in self.ciudadanos if c.esta_recuperado())
        return sanos, infectados, recuperados
