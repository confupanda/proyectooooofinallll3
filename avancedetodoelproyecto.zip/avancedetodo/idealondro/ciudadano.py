import random

class Ciudadano:
    def __init__(self, id, nombre, apellido, familia, enfermedad=None):
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
        self.familia = familia
        self.enfermedad = enfermedad
        self.estado = "sano"

    def infectar(self, enfermedad):
        self.enfermedad = enfermedad
        self.estado = "infectado"

    def recuperar(self):
        self.enfermedad = None
        self.estado = "recuperado"

    def esta_sano(self):
        return self.estado == "sano"

    def esta_infectado(self):
        return self.estado == "infectado"

    def esta_recuperado(self):
        return self.estado == "recuperado"
