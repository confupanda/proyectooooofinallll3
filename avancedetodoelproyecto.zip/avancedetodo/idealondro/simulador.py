import csv
import matplotlib.pyplot as plt
from comunidad import Comunidad

class Simulador:
    def __init__(self):
        self.comunidad = None
        self.num_pasos = 0

    def set_comunidad(self, comunidad):
        self.comunidad = comunidad

    def set_num_pasos(self, num_pasos):
        self.num_pasos = num_pasos

    def iniciar_simulacion(self):
        estados = []

        for paso in range(self.num_pasos):
            self.comunidad.paso()
            sanos, infectados, recuperados = self.comunidad.contar_estados()
            estados.append((sanos, infectados, recuperados))
            self.guardar_estado_csv(paso, sanos, infectados, recuperados)

        self.graficar_estados(estados)

    def guardar_estado_csv(self, paso, sanos, infectados, recuperados):
        with open(f'simulacion_pasoooo_{paso}.csv', mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Paso', 'Sanos', 'Infectados', 'Recuperados'])
            writer.writerow([paso, sanos, infectados, recuperados])

    def graficar_estados(self, estados):
        pasos = range(self.num_pasos)
        sanos = [estado[0] for estado in estados]
        infectados = [estado[1] for estado in estados]
        recuperados = [estado[2] for estado in estados]

        plt.plot(pasos, sanos, label='Sanos')
        plt.plot(pasos, infectados, label='Infectados')
        plt.plot(pasos, recuperados, label='Recuperados')
        plt.xlabel('Pasos')
        plt.ylabel('Número de personas')
        plt.title('Simulación SIR')
        plt.legend()
        plt.show()
