from interfaz import Interfaz

if __name__ == "__main__":
    app = Interfaz()
    app.run(None)