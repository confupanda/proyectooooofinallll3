from interfaz import Interfaz

app = Interfaz()
app.run(None)





















#beta probalidades de infectarse
#gamma la duracion de la enfermedad
#agregar modelo sir







#crear id familiar, ademas cuando el apellido se repite 3-5 veces deje de ocuparlo este
#agrupar 3 personas con el mismo apellido para formar la familia 
#que una persona contagiada tenga la posibilidad de enfermar a maximo 4 personas por dia 
#que la probabilidad de contagio entre familia sea de 0.7 y 0,3 con los demas
#enfermos por dia a comparacion del dia anterior(enfermos por fia en resultados.csv) agregar 
#graficar las personas sanas


















#ocupar np,random.normal